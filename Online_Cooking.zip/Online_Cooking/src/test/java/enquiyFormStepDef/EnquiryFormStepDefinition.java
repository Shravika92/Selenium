package enquiyFormStepDef;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.EnquiryBeanFactory;

public class EnquiryFormStepDefinition {
	
	private WebDriver driver;
	private EnquiryBeanFactory enquiryBeanFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\shkoduku\\Desktop\\Module 4\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'Online Cooking Class Enquiry Form' page$")
	public void user_is_on_Online_Cooking_Class_Enquiry_Form_page() throws Throwable {
	    
		driver.get("D:/Users/shkoduku/Desktop/Set8/SET08/Recipe_class_registration.html");
		enquiryBeanFactory = new EnquiryBeanFactory(driver);
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
	   enquiryBeanFactory.setFirstName("");
	   enquiryBeanFactory.setConfirmButton();
	}

	@Then("^displays 'First Name must be filled out'$")
	public void displays_Please_fill_the_first_Name() throws Throwable {
		String expectedMessage="First Name must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("");
		enquiryBeanFactory.setConfirmButton();
	}

	
	@Then("^displays 'Last Name must be filled out'$")
	public void displays_Last_Name_must_be_filled_out() throws Throwable {
		String expectedMessage="Last Name must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("Bhanu");
		enquiryBeanFactory.setEmail("");
		enquiryBeanFactory.setConfirmButton();
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Email")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("Bhanu");
		enquiryBeanFactory.setEmail("balabhanu@gmail.com");
		enquiryBeanFactory.setMobileNo("");
		enquiryBeanFactory.setConfirmButton();
	}
	
	@Then("^display 'Enter Numeric value'$")
	public void display_Enter_Numeric_value() throws Throwable {
		Alert alt = driver.switchTo().alert();
		String msg = alt.getText();
		if (msg.equals("Enter Numeric value")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	
	@When("^user enters wrong mobile number$")
	public void user_enters_wrong_mobile_number() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("Bhanu");
		enquiryBeanFactory.setEmail("balabhanu@gmail.com");
		enquiryBeanFactory.setMobileNo("9949");
		enquiryBeanFactory.setConfirmButton();
	}

	@Then("^display 'Enter 10 digit Mobile number'$")
	public void display_Enter_10_digit_Mobile_Number() throws Throwable {
		Alert alt = driver.switchTo().alert();
		String msg = alt.getText();
		if (msg.equals("Enter 10 digit Mobile number")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user does not fill the category$")
	public void user_does_not_fill_the_category() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("Bhanu");
		enquiryBeanFactory.setEmail("balabhanu@gmail.com");
		enquiryBeanFactory.setMobileNo("9949556124");
		enquiryBeanFactory.setCategoryRecipe("");
		enquiryBeanFactory.setConfirmButton();
	}

	@Then("^display 'Please fill the caterogy'$")
	public void display_Please_fill_the_caterogy() throws Throwable {
		Alert alt = driver.switchTo().alert();
		String msg = alt.getText();
		if (msg.equals("Please fill the category")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("Bhanu");
		enquiryBeanFactory.setEmail("balabhanu@gmail.com");
		enquiryBeanFactory.setMobileNo("9949556124");
		enquiryBeanFactory.setCategoryRecipe("Non-Veg");
		enquiryBeanFactory.setCity(null);
		enquiryBeanFactory.setConfirmButton();
	}

	@Then("^display 'Please select City'$")
	public void display_Please_fill_City() throws Throwable {
		Alert alt = driver.switchTo().alert();
		String msg = alt.getText();
		if (msg.equals("Please select city")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters invalid Mode of learning$")
	public void user_enters_invalid_Mode_of_learning() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("Bhanu");
		enquiryBeanFactory.setEmail("balabhanu@gmail.com");
		enquiryBeanFactory.setMobileNo("9949556124");
		enquiryBeanFactory.setCategoryRecipe("Non-Veg");
		enquiryBeanFactory.setCity("Mumbai");
		enquiryBeanFactory.setModeLearning("");
		enquiryBeanFactory.setConfirmButton();
	}

	@Then("^display 'Please enter valid Mode'$")
	public void display_Please_enter_valid_Mode() throws Throwable {
		Alert alt = driver.switchTo().alert();
		String msg = alt.getText();
		if (msg.equals("Please enter valid Mode")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters invalid Duration of Course$")
	public void user_enters_invalid_Duration_of_Course() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("Bhanu");
		enquiryBeanFactory.setEmail("balabhanu@gmail.com");
		enquiryBeanFactory.setMobileNo("9949556124");
		enquiryBeanFactory.setCategoryRecipe("Non-Veg");
		enquiryBeanFactory.setCity("Mumbai");
		enquiryBeanFactory.setModeLearning("In house training");
		enquiryBeanFactory.setDuration("");
		enquiryBeanFactory.setConfirmButton();
	}

	@Then("^display 'Please select Duration of Course'$")
	public void display_Please_fill_Duration_of_Course() throws Throwable {
		Alert alt = driver.switchTo().alert();
		String msg = alt.getText();
		if (msg.equals("Please select Duration of course")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters invalid Your Enquiry$")
	public void user_enters_invalid_Your_Enquiry() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("Bhanu");
		enquiryBeanFactory.setEmail("balabhanu@gmail.com");
		enquiryBeanFactory.setMobileNo("9949556124");
		enquiryBeanFactory.setCategoryRecipe("Non-Veg");
		enquiryBeanFactory.setCity("Mumbai");
		enquiryBeanFactory.setModeLearning("In house training");
		enquiryBeanFactory.setDuration("6 months");
		enquiryBeanFactory.setEnquiryDetails("");
		enquiryBeanFactory.setConfirmButton();
	}

	@Then("^display 'Enquiry details must be filled out'$")
	public void display_Enquiry_details_must_be_filled_out() throws Throwable {
		Alert alt = driver.switchTo().alert();
		String msg = alt.getText();
		if (msg.equals("Enquiry details must be filled out")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}
	
	@When("^user enters an invalid detail$")
	public void user_enters_an_invalid_detail() throws Throwable {
		
	}
	
	@Then("^he clicks on reset$")
	public void he_clicks_on_reset() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("dgsgzs");
		driver.findElement(By.id("Submit2")).click();
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		enquiryBeanFactory.setFirstName("Bala");
		enquiryBeanFactory.setLastName("Bhanu");
		enquiryBeanFactory.setEmail("balabhanu@gmail.com");
		enquiryBeanFactory.setMobileNo("9949556124");
		enquiryBeanFactory.setCategoryRecipe("Non-Veg");
		enquiryBeanFactory.setCity("Mumbai");
		enquiryBeanFactory.setModeLearning("In house training");
		enquiryBeanFactory.setDuration("6 months");
		enquiryBeanFactory.setEnquiryDetails("I love the page");
		enquiryBeanFactory.setConfirmButton();
	}
	
	@Then("^'Successfully submitted'$")
	public void successfully_submitted() throws Throwable {
		String expectedMessage="Thank you for submitting the online recipe class Enquiry";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.get("D:/Users/shkoduku/Desktop/Set8/SET08/Recipe_class_registration.html");
		driver.close();
	}
	
	@When("^he clicks on the Download our Recipe class Brochure$")
	public void he_clicks_on_the_Download_our_Recipe_class_Brochure() throws Throwable {
	   
	}

	@Then("^'Recipe class Brochure is sent to your registered mail id '$")
	public void recipe_class_Brochure_is_sent_to_your_registered_mail_id() throws Throwable {
		driver.findElement(By.linkText("Download our Recipe class Brochure")).click();
	    driver.get("D:\\Users\\shkoduku\\Desktop\\Module3_\\Spring\\Online_Cooking\\msg.html");
	}


}
