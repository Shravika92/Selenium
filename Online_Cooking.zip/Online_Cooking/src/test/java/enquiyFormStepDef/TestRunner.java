package enquiyFormStepDef;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"}, 
				 features = "D:\\Users\\shkoduku\\Desktop\\Module3_\\Spring\\Online_Cooking\\src\\test\\resources\\enquiryform\\enquiryForm.feature",
				 glue = {"enquiyFormStepDef"}, dryRun = false)
public class TestRunner {

}
