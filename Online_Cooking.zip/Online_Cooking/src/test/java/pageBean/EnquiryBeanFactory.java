package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class EnquiryBeanFactory {
	
	WebDriver driver;
	
	@FindBy(name="fname")
	@CacheLookup
	private WebElement firstName;
	
	@FindBy(name="lname")
	@CacheLookup
	private WebElement lastName;
	
	@FindBy(how=How.NAME, using="email")
	@CacheLookup
	private WebElement email;
	
	@FindBy(how = How.NAME, using="mobile")
	@CacheLookup
	private WebElement mobileNo;
	
	@FindBy(how=How.NAME, using="D6")
	@CacheLookup
	private WebElement categoryRecipe;
	
	@FindBy(how=How.NAME, using="D5")
	@CacheLookup
	private WebElement city;
	
	@FindBy(how=How.NAME, using="D4")
	@CacheLookup
	private WebElement modeLearning;
	
	@FindBy(how=How.NAME, using="D4")
	@CacheLookup
	private WebElement duration;
	
	@FindBy(how=How.NAME, using="enqdetails")
	@CacheLookup
	private WebElement enquiryDetails;
	
	@FindBy(how=How.ID, using="Submit1")
	@CacheLookup
	private WebElement confirmButton;

	@FindBy(how=How.ID, using="Submit2")
	@CacheLookup
	private WebElement reset;
	
	public EnquiryBeanFactory(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public WebElement getCategoryRecipe() {
		return categoryRecipe;
	}

	public void setCategoryRecipe(String categoryRecipe) {
		this.categoryRecipe.sendKeys(categoryRecipe);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getModeLearning() {
		return modeLearning;
	}

	public void setModeLearning(String modeLearning) {
		this.modeLearning.sendKeys(modeLearning);
	}

	public WebElement getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration.sendKeys(duration);
	}

	public WebElement getEnquiryDetails() {
		return enquiryDetails;
	}

	public void setEnquiryDetails(String enquiryDetails) {
		this.enquiryDetails.sendKeys(enquiryDetails);
	}

	public WebElement getConfirmButton() {
		return confirmButton;
	}

	public void setConfirmButton() {
		this.confirmButton.click();
	}

	public WebElement getReset() {
		return reset;
	}

	public void setReset() {
		this.reset.clear();
	}

	

}
