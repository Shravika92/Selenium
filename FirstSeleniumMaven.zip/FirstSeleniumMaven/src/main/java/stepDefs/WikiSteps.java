package stepDefs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WikiSteps {
	WebDriver driver;
	@Given("^User is on home page$")
	public void user_is_on_home_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D://Users//shkoduku//Desktop//Module 4/chromedriver.exe");
		
		 driver = new ChromeDriver();
		 driver.get("https://www.wikipedia.org/");
	}

	@When("^he gives input as India$")
	public void he_gives_input_as_India() throws Throwable {
		driver.findElement(By.xpath("//input[@id='searchInput']")).sendKeys("India");
	    
	}

	@Then("^the search is done$")
	public void the_search_is_done() throws Throwable {
		driver.findElement(By.xpath("//i[@class='sprite svg-search-icon']")).click();
	   
	}

	@Then("^India page on wikipedia is displayed$")
	public void india_page_on_wikipedia_is_displayed() throws Throwable {
	    if(driver.getTitle().equals("India - Wikipedia")) {
	    	System.out.println("Im happyy.....");
	    }
	}

}
